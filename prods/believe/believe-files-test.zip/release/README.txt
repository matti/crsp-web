BELIEVE - CR!SP x HEDELMAE
Skrolli Party 2026 - Amiga 1200 vibedemo - 4th place

Updated stereo soundtrack and credits timing.

Requires A1200, AGA, 68020, 2 MB Chip RAM, Kickstart 3.x.
Native A1200 IDE/CF master, FFS with 512-byte blocks.
The partition must lie entirely below 2 GB on the disk.
PFS3, SFS, PCMCIA and UAE directory mounts are not supported.

Copy this directory to the Amiga hard disk/CF.
Open a Shell, CD into this directory, then run:

  demo

Keep demo, demo.bin and music.stream together.
No disk image, repartitioning or fixed file placement is needed.
Restart the Amiga after the demo.

Audio: Mayday's signed 8-bit stereo PCM, 24000 Hz nominal.
The complete song streams from the file; no extra RAM is required.
Validated in WinUAE; physical Amiga/CF validation is pending.

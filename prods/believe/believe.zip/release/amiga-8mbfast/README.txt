BELIEVE - CR!SP x HEDELMAE - updated stereo file version

Requires A1200/AGA, 2 MB Chip RAM plus 8 MB Fast RAM, Kickstart 3.x.
Works with ordinary AmigaDOS filesystems and storage controllers.
The song is loaded into Fast RAM before the demo takes over.

Copy this directory to the Amiga disk. In a Shell, CD into it and run:

  demo

Keep demo, demo.bin and music.stream together. Restart after the demo.

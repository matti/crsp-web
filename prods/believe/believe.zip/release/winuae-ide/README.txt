BELIEVE - CR!SP x HEDELMAE - updated stereo IDE disk image

WinUAE: A1200, AGA, 68020, 2 MB Chip RAM, Kickstart 3.x.
Attach believe.hdf as a whole disk on motherboard IDE unit 0 (master).
The demo boots automatically. Supply your own Kickstart ROM.

For copying files to a real Amiga, use one of the amiga-* directories.

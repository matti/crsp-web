BELIEVE
CR!SP x HEDELMAE
Skrolli Party 2026

Amiga 1200 / AGA / 68020 / 2 MB Chip RAM / Kickstart 3.x

Boot believe.hdf as a complete hard disk on the A1200 IDE master.
In WinUAE, use the motherboard IDE controller, unit 0.
The demo starts automatically.

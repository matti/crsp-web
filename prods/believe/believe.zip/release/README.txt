BELIEVE - CR!SP x HEDELMAE
Skrolli Party 2026 - Amiga 1200 vibedemo - 4th place

All three versions contain the updated 24 kHz stereo music, corrected
Dipe/Mayday timing, and greetings including ZyL and ph0bos.

amiga-2mb/
  Stock A1200, no Fast RAM. Copy the files to native IDE/CF.
  FFS or PFS3, 512-byte filesystem blocks, LBA28 (first 128 GiB).
  Large offsets require SCSI-direct READ(10). No 2 GB partition limit.
  CD into the directory in an Amiga Shell and run: demo

amiga-8mbfast/
  A1200 with 8 MB Fast RAM, any AmigaDOS filesystem/controller.
  CD into the directory in an Amiga Shell and run: demo

winuae-ide/
  Bootable whole-disk HDF for WinUAE, motherboard IDE master.

No disk formatting or repartitioning is needed for either file version.
Validated in WinUAE. Mayday tested amiga-8mbfast on TF1260 and PiStorm:
boot without Startup-Sequence; SetPatch is OK; no cache change needed.
This update corrects render-dependent animation/fades using PAL time.
Retesting on physical TF/PiStorm machines is still needed.
The 2 MB version requires native motherboard IDE, not accelerator storage.

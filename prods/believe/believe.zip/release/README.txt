BELIEVE - CR!SP x HEDELMAE
Skrolli Party 2026 - Amiga 1200 vibedemo - 4th place

All three versions contain the updated 24 kHz stereo music, corrected
Dipe/Mayday timing, and greetings including ZyL and ph0bos.

amiga-2mb/
  Stock A1200, no Fast RAM. Copy the files to native IDE/CF.
  FFS or PFS3, 512-byte filesystem blocks, partition entirely below 2 GB.
  CD into the directory in an Amiga Shell and run: demo

amiga-8mbfast/
  A1200 with 8 MB Fast RAM, any AmigaDOS filesystem/controller.
  CD into the directory in an Amiga Shell and run: demo

winuae-ide/
  Bootable whole-disk HDF for WinUAE, motherboard IDE master.

No disk formatting or repartitioning is needed for either file version.
Validated in WinUAE. Physical Amiga/CF validation is pending.
